def add_one(number):
    return number + 1

def add_two(number):
    return number + 2